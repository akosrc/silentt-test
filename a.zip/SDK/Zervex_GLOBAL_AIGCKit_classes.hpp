#pragma once

// =============================================================================
// PUBG Mobile Global 4.7.0 (4.7.0 -- 64-Bit) SDK
// Copyright (C) 2026 Zervex RIYAZ. All Rights Reserved.
// Developed by: @Zervexcheat RIYAZ (TG: @RIYAZXERO | Channel: @RIYAZ_STUFF)
// GitHub: https://github.com/RIYAZXERO
// Generation Time: Thu Nov 12 22:34:20 2026

// =============================================================================

namespace SDK
{
//---------------------------------------------------------------------------
// Classes
//---------------------------------------------------------------------------

// Class AIGCKit.AIGCAnimData
// 0x0020 (0x0048 - 0x0028)
class UAIGCAnimData : public UObject
{
public:
	TArray<struct FAIBonesTransfroms>                  BonesTransfroms;                                          // 0x0028(0x0010) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor)
	int                                                FrameRate;                                                // 0x0038(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	bool                                               bUseCustomSpace;                                          // 0x003C(0x0001) (ZeroConstructor, IsPlainOldData)
	struct FSkeletonModifyRule                         CustomRule;                                               // 0x003D(0x0006)
	unsigned char                                      UnknownData00[0x5];                                       // 0x0043(0x0005) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class AIGCKit.AIGCAnimData");
		return pStaticClass;
	}

};


// Class AIGCKit.AIGCAnimInstance
// 0x0030 (0x0420 - 0x03F0)
class UAIGCAnimInstance : public UAnimInstance
{
public:
	unsigned char                                      UnknownData00[0x8];                                       // 0x03F0(0x0008) MISSED OFFSET
	bool                                               bUseAIGCAnimation;                                        // 0x03F8(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData01[0x3];                                       // 0x03F9(0x0003) MISSED OFFSET
	float                                              CurrentAIGCAnimFrameIndex;                                // 0x03FC(0x0004) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneModificationMode>            TranslationMode;                                          // 0x0400(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneModificationMode>            RotationMode;                                             // 0x0401(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneModificationMode>            ScaleMode;                                                // 0x0402(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneControlSpace>                TranslationSpace;                                         // 0x0403(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneControlSpace>                RotationSpace;                                            // 0x0404(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	TEnumAsByte<enum EBoneControlSpace>                ScaleSpace;                                               // 0x0405(0x0001) (BlueprintVisible, ZeroConstructor, IsPlainOldData)
	unsigned char                                      UnknownData02[0x2];                                       // 0x0406(0x0002) MISSED OFFSET
	float                                              AIGCAnimFrameRate;                                        // 0x0408(0x0004) (BlueprintVisible, BlueprintReadOnly, ZeroConstructor, IsPlainOldData)
	struct FSkeletonModifyRule                         DefaultSkeletonModifyRule;                                // 0x040C(0x0006)
	unsigned char                                      UnknownData03[0xE];                                       // 0x0412(0x000E) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class AIGCKit.AIGCAnimInstance");
		return pStaticClass;
	}


	int GetCurrentFrameIndex();
};


// Class AIGCKit.AIGCKitFunctionLibrary
// 0x0000 (0x0028 - 0x0028)
class UAIGCKitFunctionLibrary : public UBlueprintFunctionLibrary
{
public:

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class AIGCKit.AIGCKitFunctionLibrary");
		return pStaticClass;
	}


	static class UAIGCAnimData* GetAnimData(int FrameRate, int FrameNum, const struct FSkeletonNodeInfo& SkeletonNodeInfo, TArray<unsigned char>* CompressData);
	static bool DecompressBone(int TrackIndex, float Time, float RelativePos, struct FTransform* OutAtom, TArray<unsigned char>* RawAnimData);
	static bool DecompressAnimData(class UAIGCAnimData* OutAnimData, int FrameNum, float TargetFramerate, const struct FSkeletonNodeInfo& SkeletonNodeInfo, TArray<unsigned char>* RawAnimData);
};


// Class AIGCKit.AIGCKitSettings
// 0x00B0 (0x00D8 - 0x0028)
class UAIGCKitSettings : public UObject
{
public:
	TMap<struct FString, struct FSkeletonNodeInfo>     FaceSkeletons;                                            // 0x0028(0x0050) (Edit, ZeroConstructor, Config)
	TMap<struct FString, struct FSkeletonNodeInfo>     BodySkeletons;                                            // 0x0078(0x0050) (Edit, ZeroConstructor, Config)
	struct FSkeletonModifyRule                         DefaultFaceRule;                                          // 0x00C8(0x0006) (Edit, Config)
	struct FSkeletonModifyRule                         DefaultBodyRule;                                          // 0x00CE(0x0006) (Edit, Config)
	unsigned char                                      UnknownData00[0x4];                                       // 0x00D4(0x0004) MISSED OFFSET

	static UClass* StaticClass()
	{
        static UClass *pStaticClass = 0;
        if (!pStaticClass)
            pStaticClass = UObject::FindClass("Class AIGCKit.AIGCKitSettings");
		return pStaticClass;
	}

};


}

